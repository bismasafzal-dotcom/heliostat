# Heliostat

**Space weather, in plain language.** Heliostat reads NASA's live solar data and translates it into plain-language impact assessments for the systems people actually rely on — power grids, aviation, and satellite navigation — plus an aurora-visibility check for your latitude.

- **Landing page** (`index.html`) — the marketing site.
- **Monitor** (`monitor.html`) — the live dashboard that pulls from NASA's DONKI API.

No build step, no dependencies, no backend. Just static HTML, CSS, and vanilla JavaScript.

---

## Live demo

Once deployed (see below), your site will be at:

```
https://<your-username>.github.io/heliostat/
```

The monitor lives at `…/heliostat/monitor.html`, and the landing page's "Open the monitor" buttons link to it.

---

## Deploy to GitHub Pages

### Option A — Git command line

1. **Create a new repository** on GitHub named `heliostat` (public). Don't add a README or .gitignore — this folder already has what you need.

2. **Push these files** from the folder that contains `index.html`:

   ```bash
   git init
   git add .
   git commit -m "Heliostat: landing page + live space-weather monitor"
   git branch -M main
   git remote add origin https://github.com/<your-username>/heliostat.git
   git push -u origin main
   ```

3. **Turn on Pages:** on GitHub, go to your repo → **Settings** → **Pages** → under **Build and deployment**, set **Source** to **Deploy from a branch**, choose **Branch: `main`** and **folder: `/ (root)`**, then **Save**.

4. **Wait about a minute.** Refresh the Pages settings screen; it'll show your live URL. Done.

### Option B — No command line (upload in the browser)

1. Create the `heliostat` repository on GitHub.
2. On the repo page, click **Add file → Upload files**, drag in `index.html`, `monitor.html`, `.nojekyll`, and `README.md`, then **Commit changes**.
3. Follow **step 3** above to enable Pages.

> **Tip:** `index.html` is served automatically at the root URL, so visitors land on the marketing page first. The `.nojekyll` file tells GitHub to publish the files as-is (no Jekyll processing) — leave it in.

---

## NASA API key

The app works out of the box with NASA's shared `DEMO_KEY`, but it's rate-limited (~30 requests/hour per IP). For smooth use:

1. Get a free key at **[api.nasa.gov](https://api.nasa.gov/)** (name + email, emailed instantly, ~1,000 requests/hour).
2. Open the monitor, click the **gear icon (Settings)**, and paste your key in. It's saved in your browser only — never committed to the repo.

**A note on the landing page's live readout:** the hero fetches the current Kp index with `DEMO_KEY`, which is shared across all visitors. Under real traffic it can hit the rate limit, in which case it degrades gracefully to a labeled reference scale (no broken state). GitHub Pages is static-only, so there's no way to hide a key or proxy the request server-side here — if you later want guaranteed liveness, put a small serverless function (Cloudflare Workers, Netlify, Vercel) in front of the NASA call and point the fetch at it.

---

## Run locally

Because the pages call the NASA API over `https`, open them through a local server rather than double-clicking the file (some browsers block `fetch` from `file://`):

```bash
# from the project folder
python3 -m http.server 8000
# then visit http://localhost:8000
```

---

## Project structure

```
heliostat/
├── index.html      # Landing page
├── monitor.html    # Live space-weather monitor
├── .nojekyll       # Publish static files as-is on GitHub Pages
└── README.md
```

Each HTML file is fully self-contained (styles and scripts inline), so there are no asset paths to break when hosting from a project subpath.

---

## How it works

The monitor pulls three feeds from NASA's [DONKI](https://ccmc.gsfc.nasa.gov/tools/DONKI/) service — solar flares (FLR), coronal mass ejections (CME), and geomagnetic storms (GST) — reads the latest Kp index, and maps it through a severity model onto three impact domains. Severity is expressed on NOAA's G1–G5 scale, the same one grid operators and aviators use.

## Data & disclaimer

Solar data: **NASA DONKI**. Severity scale: **NOAA G1–G5**.

Impact levels are simplified public-guidance estimates, **not an operational forecast**. For flight, grid, or emergency decisions, consult [NOAA's Space Weather Prediction Center](https://www.swpc.noaa.gov/) directly.

## License

MIT — do what you like, no warranty. Add a `LICENSE` file if you want it formalized.
